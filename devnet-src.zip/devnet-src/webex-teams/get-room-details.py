# Fill in this file with the code to get room details from the Webex Teams exercise
